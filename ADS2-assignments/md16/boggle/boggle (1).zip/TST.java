/**
 * Class for tst.
 *
 * @param      <Value>  The value
 */
class TST<Value> {
    /**
     * int variable.
     */
    private int size;
    /**
     * Node object.
     */
    private Node<Value> root;
    /**
     * Class for node.
     *
     * @param      <Value>  The value
     */
    class Node<Value> {
        /**
         * char variable.
         */
        private char character;
        /**
         * node object.
         */
        private Node<Value> left;
        /**
         * node object.
         */
        private Node<Value> middle;
        /**
         * node object.
         */
        private Node<Value> right;
        /**
         * value variable.
         */
        private Value value;
    }
    /**
     * Constructs the object.
     */
    TST() {
        size = 0;
    }
    /**
     * checks if the string is present or not.
     * complexity is O(L + logN)
     * L length of string, N trie size.
     * because we are calling the get method.
     * @param      i   i
     *
     * @return     boolean value.
     */
    public boolean contains(final String i) {
        return get(i) != null;
    }
    /**
     * helper method for the main get method.
     * complexity is O(L + logN)
     * L length of string, N trie size.
     * @param      i   i
     *
     * @return     the string.
     */
    public Value get(final String i) {
        Node<Value> node = get(root, i, 0);
        if (node == null) {
            return null;
        }
        return node.value;
    }
    /**
     * it returns the value.
     * complexity is O(L + logN)
     * L length of string, N trie size.
     * @param      node  The node
     * @param      i   i
     * @param      d     the character
     *
     * @return     node object.
     */
    public Node<Value> get(final Node<Value> node,
                           final String i, final int d) {
        if (node == null) {
            return null;
        }
        char ch = i.charAt(d);
        if (ch < node.character) {
            return get(node.left,  i, d);
        } else if (ch > node.character) {
            return get(node.right, i, d);
        } else if (d < i.length() - 1) {
            return get(node.middle, i, d + 1);
        } else {
            return node;
        }
    }
    /**
     * helper method for the main put method.
     * complexity is O(L + logN)
     * L length of string, N trie size.
     * @param      i    i
     * @param      value  The value
     */
    public void put(final String i, final Value value) {
        if (!contains(i)) {
            size++;
        }
        root = put(root, i, value, 0);
    }
    /**
     * used to put the string with the assigned value.
     * complexity is O(L + logN)
     * L length of string, N trie size.
     * @param      node   The node
     * @param      i    i
     * @param      value  The value
     * @param      d      the charcter index.
     *
     * @return     Node object.
     */
    public Node<Value> put(final Node<Value> node,
                           final String i, final Value value,
                           final int d) {
        Node<Value> node1 = node;
        char ch = i.charAt(d);
        if (node1 == null) {
            node1 = new Node<Value>();
            node1.character = ch;
        }
        if (ch < node1.character) {
            node1.left  = put(node1.left,  i, value, d);
        } else if (ch > node1.character) {
            node1.right = put(node1.right, i, value, d);
        } else if (d < i.length() - 1) {
            node1.middle   = put(node1.middle, i, value, d + 1);
        } else {
            node1.value   = value;
        }
        return node1;
    }
    /**
     * used to find the string with the prefix.
     * complexity is O(L + logN)
     * L length of string, N trie size.
     * @param      i   i
     *
     * @return    Iterable.
     */
    public Iterable<String> keysWithPrefix(final String i) {
        Queue1<String> que = new Queue1<String>();
        Node<Value> x = get(root, i, 0);
        if (x == null) {
            return que;
        }
        if (x.value != null) {
            que.enqueue(i);
        }
        collect(x.middle, new StringBuilder(i), que);
        return que;
    }
    /**
     * checks for the strings with the preffix
     * in trie.
     * complexity is O(L + logN)
     * L length of string, N trie size.
     * @param      node  The node
     * @param      i   i
     * @param      que   The que
     */
    public void collect(final Node<Value> node,
                        final StringBuilder i, final Queue1<String> que) {
        if (node == null) {
            return;
        }
        collect(node.left,  i, que);
        if (node.value != null) {
            que.enqueue(i.toString()
                        + node.character);
        }
        collect(node.middle, i.append(
                    node.character), que);
        i.deleteCharAt(i.length() - 1);
        collect(node.right, i, que);
    }
    /**
     * Determines if prefix is present or not.
     *
     * @param      prefix  The prefix
     *
     * @return     True if prefix, False otherwise.
     */
    public boolean isPrefix(final String prefix) {
        return get(root, prefix, 0) != null;
    }
}
